package entity

import (
	"container/heap"
	"errors"
)

type ParkingSpaceFinderStrategy interface {
	Find() (ParkingSpace, error)
	Fill(ps ParkingSpace) error
	Empty(ps ParkingSpace)
}

type NearElevatorStrategy struct {
	nearElevatorHeap *NearElevatorHeap
}

func NewNearElevatorStrategy(parkingSpaces []ParkingSpace) NearElevatorStrategy {

	nearElevatorHeap := &NearElevatorHeap{}
	heap.Init(nearElevatorHeap)

	for _, val := range parkingSpaces {
		heap.Push(nearElevatorHeap, val)
	}

	return NearElevatorStrategy{
		nearElevatorHeap: nearElevatorHeap,
	}
}

func (n NearElevatorStrategy) Find() (ParkingSpace, error) {

	if n.nearElevatorHeap.Len() <= 0 {
		return ParkingSpace{}, errors.New("no parking space left")
	}
	return (*n.nearElevatorHeap)[0], nil
}

func (n NearElevatorStrategy) Fill(ps ParkingSpace) error {
	x := heap.Pop(n.nearElevatorHeap).(ParkingSpace)
	if x.Id != ps.Id {
		return errors.New("parking space cannot be filled")
	}
	return nil
}

func (n NearElevatorStrategy) Empty(ps ParkingSpace) {
	heap.Push(n.nearElevatorHeap, ps)
}

// TODO: Below implementation is incomplete. Please complete the implementation
type NearElevatorAndNearEscalatorStrategy struct {
	nearELevatorAndNearEscalatorHeap *NearELevatorAndNearEscalatorHeap
}

func NewNearElevatorAndNearEscalatorStrategy(parkingSpaces []ParkingSpace) NearElevatorAndNearEscalatorStrategy {
	nearELevatorAndNearEscalatorHeap := &NearELevatorAndNearEscalatorHeap{}
	heap.Init(nearELevatorAndNearEscalatorHeap)

	for _, val := range parkingSpaces {
		heap.Push(nearELevatorAndNearEscalatorHeap, val)
	}

	return NearElevatorAndNearEscalatorStrategy{
		nearELevatorAndNearEscalatorHeap: nearELevatorAndNearEscalatorHeap,
	}

}
func (n NearElevatorAndNearEscalatorStrategy) Find() (ParkingSpace, error) {

	return heap.Pop(n.nearELevatorAndNearEscalatorHeap).(ParkingSpace), nil
}

func (n NearElevatorAndNearEscalatorStrategy) Fill(ps ParkingSpace) error {
	return nil
}

func (n NearElevatorAndNearEscalatorStrategy) Empty(ps ParkingSpace) {
	return
}

type Default struct {
}

func NewDefault() Default {
	return Default{}
}

func (d Default) Find() (ParkingSpace, error) {
	return ParkingSpace{}, nil
}

func (d Default) Fill(ps ParkingSpace) error {
	return nil

}

func (d Default) Empty(ps ParkingSpace) {
	return
}
