package entity

import "solid_design/parking_lot/enums"

type ParkingSpace struct {
	Id                               int
	IsOccupied                       bool
	vehicle                          Vehicle
	DistanceFromElavator             int
	DistanceFromElevatorAndEscalator int
	vehicleType                      enums.VehicleType
	PriceCalculationStrategy         PriceCalculationStrategy
}

type TwoWheelerParkingSpace struct {
	ParkingSpace ParkingSpace
}

type FourWheelerParkingSpace struct {
	ParkingSpace ParkingSpace
}

func NewTwoWheelerParkingSpace() TwoWheelerParkingSpace {
	return TwoWheelerParkingSpace{
		ParkingSpace: ParkingSpace{
			IsOccupied:               false,
			vehicleType:              enums.TwoWheeler,
			PriceCalculationStrategy: NewPriceCalculationStrategy("hourly")},
	}
}

func NewFourWheelerParkingSpace() FourWheelerParkingSpace {
	return FourWheelerParkingSpace{ParkingSpace: ParkingSpace{IsOccupied: false, vehicleType: enums.FourWheeler, PriceCalculationStrategy: NewPriceCalculationStrategy("minute")}}
}
