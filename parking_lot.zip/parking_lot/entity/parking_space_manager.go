package entity

import (
	"errors"
	"math/rand"
)

type ParkingSpaceManager interface {
	AddParkingSpace(n int) error
	RemoveParkingSpace(n int) error
	BookParkingSpace(ps ParkingSpace) error
	FindParkingSpace() (ParkingSpace, error)
	EmptyParkingSpace(ps ParkingSpace)
}

type TwoWheelerParkingSpaceManager struct {
	parkingSpaces    []ParkingSpace
	psFinderStrategy ParkingSpaceFinderStrategy
}

func NewTwoWheelerParkingSpaceManager() TwoWheelerParkingSpaceManager {

	ps := make([]ParkingSpace, 10)

	for i := 0; i < 10; i++ {

		ps[i] = ParkingSpace{
			Id:                               i,
			IsOccupied:                       false,
			DistanceFromElevatorAndEscalator: rand.Int() % 97,
			DistanceFromElavator:             rand.Int() % 93,
			PriceCalculationStrategy:         NewPriceCalculationStrategy("hourly"),
		}
	}

	return TwoWheelerParkingSpaceManager{
		parkingSpaces:    ps,
		psFinderStrategy: NewNearElevatorStrategy(ps),
	}
}

func (t *TwoWheelerParkingSpaceManager) AddParkingSpace(n int) error {
	if n <= 0 {
		return errors.New("number of parking spaces should be greater than 0")
	}

	t.parkingSpaces = append(t.parkingSpaces, make([]ParkingSpace, n)...)
	return nil
}

func (t *TwoWheelerParkingSpaceManager) RemoveParkingSpace(n int) error {
	if n <= 0 {
		return errors.New("number of parking spaces should be greater than 0")
	}

	if n > len(t.parkingSpaces) {
		return errors.New("number of parking spaces to remove is greater than available parking spaces")
	}

	t.parkingSpaces = t.parkingSpaces[:len(t.parkingSpaces)-n]
	return nil
}

func (t *TwoWheelerParkingSpaceManager) FindParkingSpace() (ParkingSpace, error) {
	return t.psFinderStrategy.Find()
}

func (t *TwoWheelerParkingSpaceManager) BookParkingSpace(ps ParkingSpace) error {

	if ps.IsOccupied {
		return errors.New("parking space is already occupied")
	}

	ps.IsOccupied = true

	for i, val := range t.parkingSpaces {
		if val.Id == ps.Id {
			t.parkingSpaces[i] = ps
			break
		}
	}
	return t.psFinderStrategy.Fill(ps)

}

func (t *TwoWheelerParkingSpaceManager) GetParkingSpaces() []ParkingSpace {
	return t.parkingSpaces
}

func (t *TwoWheelerParkingSpaceManager) EmptyParkingSpace(ps ParkingSpace) {
	ps.IsOccupied = false
	t.parkingSpaces[ps.Id] = ps
	t.psFinderStrategy.Empty(ps)
}

// TODO:  Placeholder for FourWheelerParkingSpaceManager implementation
type FourWheelerParkingSpaceManager struct {
	parkingSpaces []ParkingSpace
}

func NewFourWheelerParkingSpaceManager() FourWheelerParkingSpaceManager {
	return FourWheelerParkingSpaceManager{}
}

func (f FourWheelerParkingSpaceManager) AddParkingSpace(n int) error {
	return nil
}

func (f FourWheelerParkingSpaceManager) RemoveParkingSpace(n int) error {
	return nil
}

func (f FourWheelerParkingSpaceManager) BookParkingSpace(ps ParkingSpace) error {
	return nil
}

func (f FourWheelerParkingSpaceManager) FindParkingSpace() (ParkingSpace, error) {
	return ParkingSpace{}, nil
}

func (f FourWheelerParkingSpaceManager) EmptyParkingSpace(ps ParkingSpace) {
	return
}
