package entity

import "time"

type PriceCalculationStrategy interface {
	CalculatePrice(ticket Ticket) float64
}

type FixedPrice struct {
	price float64
}

func (f FixedPrice) CalculatePrice(ticket Ticket) float64 {
	return f.price
}

type HourlyPrice struct {
}

func NewHourlyPrice() HourlyPrice {
	return HourlyPrice{}
}

func (h HourlyPrice) CalculatePrice(ticket Ticket) float64 {
	return time.Now().Sub(ticket.entryTime).Seconds() * 10
}

type MinutePrice struct {
}

func (m MinutePrice) CalculatePrice(ticket Ticket) float64 {
	return time.Now().Sub(ticket.entryTime).Minutes() * 0.2
}

func NewPriceCalculationStrategy(priceType string) PriceCalculationStrategy {
	switch priceType {
	case "fixed":
		return FixedPrice{price: 100}
	case "hourly":
		return HourlyPrice{}
	case "minute":
		return MinutePrice{}
	default:
		return nil
	}
}
